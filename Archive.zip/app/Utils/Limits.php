<?php


namespace App\Utils;


class Limits
{
    const PER_PAGE = 10;
    const KEY_WORD = '(need to follow up)';
}
